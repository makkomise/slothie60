G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*
G04 #@! TF.CreationDate,2026-02-21T11:30:29+02:00*
G04 #@! TF.ProjectId,rev1c.kicad_plate,72657631-632e-46b6-9963-61645f706c61,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-02-21 11:30:29*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
